package com.saggezza.productservice.Service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.saggezza.productservice.pojos.CatalogProds;
import com.saggezza.productservice.pojos.Product;
import com.saggezza.productservice.pojos.ProductCatalogs;
import com.saggezza.productservice.service.CatalogProductService;

@ExtendWith(MockitoExtension.class)
public class CatalogProductsServiceTests {
	
	@Mock
	ProductCatalogs productCatalogs;

	@InjectMocks
	CatalogProductService catalogProductService;
	
	public ProductCatalogs getCatalogProds() {
		ProductCatalogs prodCatalogs = new ProductCatalogs();
		Product p1 = new Product(1, "shirt", "bodywear", 45.0, true);
		Product p2 = new Product(2, "pant", "bodywear", 25.0, true);
		Product p3 = new Product(3, "shoes", "bodywear", 15.0, false);
		List<Product> prods = new ArrayList<Product>();
		prods.add(p1);
		prods.add(p2);
		prods.add(p3);
		CatalogProds catProd = new CatalogProds(1, "firstCatalog", prods);
		Product p4 = new Product(4, "skarf", "bodywear", 45.0, true);
		Product p5 = new Product(5, "tie", "bodywear", 43.0, true);
		Product p6 = new Product(6, "cap", "bodywear", 11.0, true);
		List<Product> prods2 = new ArrayList<Product>();
		prods2.add(p4);
		prods2.add(p5);
		prods2.add(p6);
		CatalogProds catProd2 = new CatalogProds(2, "secondCatalog", prods2);
		List<CatalogProds> catalogProds = new ArrayList<>();
		catalogProds.add(catProd);
		catalogProds.add(catProd2);
		prodCatalogs.setCatalogProds(catalogProds);
		return prodCatalogs;
	}

	

	@Test
	public void getSingleProduct() {
		Mockito.when(productCatalogs.getCatalogProds()).thenReturn(getCatalogProds().getCatalogProds());
		Product prod = catalogProductService.fetchProduct(1, 1);
		assertNotNull(prod);
		assertEquals(prod.getProductName(), "shirt");
	}

	@Test
	public void getSingleProductNullFound() {
		Mockito.when(productCatalogs.getCatalogProds()).thenReturn(getCatalogProds().getCatalogProds());
		Product prod = catalogProductService.fetchProduct(1, 7);
		assertNull(prod);
	}

}
