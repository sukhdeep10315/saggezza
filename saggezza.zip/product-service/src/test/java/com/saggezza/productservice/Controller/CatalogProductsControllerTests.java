package com.saggezza.productservice.Controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.saggezza.productservice.Exception.ProductNotFoundExcpetion;
import com.saggezza.productservice.pojos.Product;
import com.saggezza.productservice.service.CatalogProductService;

@ExtendWith(MockitoExtension.class)
public class CatalogProductsControllerTests {
	
	@InjectMocks
	CatalogProductsController catalogProductsController;
	
	@Mock
	CatalogProductService catalogProductService;
	
	
	public Product getProduct() {
		Product p1 = new Product(1, "shirt", "bodywear", 45.0, true);
		return p1;
	}
	
	@Test
	public void getSingleProductTest() {
		Mockito.when(catalogProductService.fetchProduct(1, 1)).thenReturn(getProduct());
		Product prod = catalogProductsController.getSingleProduct(1, 1);
		assertEquals(prod.getProductName(),"shirt");
	}

	@Test
	public void getSingleProductExceptionTest() {
		Mockito.when(catalogProductService.fetchProduct(1, 7)).thenReturn(null);
		assertThrows(ProductNotFoundExcpetion.class,()-> catalogProductsController.getSingleProduct(1, 7));
	}
}
