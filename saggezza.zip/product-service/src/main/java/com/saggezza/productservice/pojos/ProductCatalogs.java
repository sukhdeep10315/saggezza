package com.saggezza.productservice.pojos;

import java.util.List;

public class ProductCatalogs {
	List<CatalogProds> catalogProds;

	public List<CatalogProds> getCatalogProds() {
		return catalogProds;
	}

	public void setCatalogProds(List<CatalogProds> catalogProds) {
		this.catalogProds = catalogProds;
	}
	
	
}
