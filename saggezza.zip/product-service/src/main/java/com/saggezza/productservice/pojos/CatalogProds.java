package com.saggezza.productservice.pojos;

import java.util.List;

public class CatalogProds {
	private int id;
	private String catalogName;
	private List<Product> products;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCatalogName() {
		return catalogName;
	}

	public void setCatalogName(String catalogName) {
		this.catalogName = catalogName;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public CatalogProds(int id, String catalogName, List<Product> products) {
		super();
		this.id = id;
		this.catalogName = catalogName;
		this.products = products;
	}
	
	

}
