package com.saggezza.productservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.saggezza.productservice.pojos.CatalogProds;
import com.saggezza.productservice.pojos.Product;
import com.saggezza.productservice.pojos.ProductCatalogs;


@Service
public class CatalogProductService {
	
	@Autowired
	ProductCatalogs productCatalogs;
	
	public ProductCatalogs getProductCatalogs() {
		return productCatalogs;
	}

	public void setProductCatalogs(ProductCatalogs productCatalogs) {
		this.productCatalogs = productCatalogs;
	}

	public ProductCatalogs fetchAll() {
		return productCatalogs;
	}

	public Product fetchProduct(int id,int catalogId) {
		Product product=null;
		for(CatalogProds catProd:productCatalogs.getCatalogProds()) {
			if(catProd.getId()==catalogId) {
				for(Product prod:catProd.getProducts()) {
					if(prod.getId()==id) {
						product=prod;
					}
				}
			}
		}
		return product;
	}

}
