package com.saggezza.productservice.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.saggezza.productservice.Exception.ProductNotFoundExcpetion;
import com.saggezza.productservice.pojos.Product;
import com.saggezza.productservice.pojos.ProductCatalogs;
import com.saggezza.productservice.service.CatalogProductService;

@RestController
@RequestMapping("/catalogProducts")
public class CatalogProductsController {

	@Autowired
	CatalogProductService catalogProductService;

	@GetMapping
	public ProductCatalogs getAllProducts() {
		ProductCatalogs prod = catalogProductService.fetchAll();
		return prod;
	}
	
	@GetMapping("/{catalogId}/productId/{id}")
	public Product getSingleProduct(@PathVariable int id,@PathVariable int catalogId) {
		Product prod = catalogProductService.fetchProduct(id,catalogId);
		if(prod==null) {
			throw new ProductNotFoundExcpetion("Either Product/Catalog Not found", "Please retry with actual ids");
		}
		return prod;
	}

}
