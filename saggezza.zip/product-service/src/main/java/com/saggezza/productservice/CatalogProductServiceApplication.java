package com.saggezza.productservice;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;

import com.saggezza.productservice.pojos.CatalogProds;
import com.saggezza.productservice.pojos.Product;
import com.saggezza.productservice.pojos.ProductCatalogs;

@SpringBootApplication
@EnableDiscoveryClient
public class CatalogProductServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatalogProductServiceApplication.class, args);
	}
	
	@Bean
	public ProductCatalogs maintainProductList(){
		ProductCatalogs prodCatalogs=new ProductCatalogs();
		Product p1=new Product(1,"shirt","bodywear",45.0,true);
		Product p2=new Product(2,"pant","bodywear",25.0,true);
		Product p3=new Product(3,"shoes","bodywear",15.0,false);
		List<Product> prods=new ArrayList<Product>();
		prods.add(p1);
		prods.add(p2);
		prods.add(p3);
		CatalogProds catProd=new CatalogProds(1, "firstCatalog", prods);
		Product p4=new Product(4,"skarf","bodywear",45.0,true);
		Product p5=new Product(5,"tie","bodywear",43.0,true);
		Product p6=new Product(6,"cap","bodywear",11.0,true);
		List<Product> prods2=new ArrayList<Product>();
		prods2.add(p4);
		prods2.add(p5);
		prods2.add(p6);
		CatalogProds catProd2=new CatalogProds(2, "secondCatalog", prods2);
		List<CatalogProds> catalogProds=new ArrayList<>();
		catalogProds.add(catProd);
		catalogProds.add(catProd2);
		prodCatalogs.setCatalogProds(catalogProds);
		return prodCatalogs;
	}

}
