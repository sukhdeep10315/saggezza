package com.saggezza.shopCartService.exception;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class CustomErrorResponse {
	
	public String getErroMessage() {
		return erroMessage;
	}
	public void setErroMessage(String erroMessage) {
		this.erroMessage = erroMessage;
	}
	public List<String> getErrorDetails() {
		return errorDetails;
	}
	public void setErrorDetails(List<String> errorDetails) {
		this.errorDetails = errorDetails;
	}
	
	String erroMessage;
	List<String> errorDetails;

}
