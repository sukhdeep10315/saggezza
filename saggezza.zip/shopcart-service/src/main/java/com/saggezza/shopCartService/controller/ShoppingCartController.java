package com.saggezza.shopCartService.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.saggezza.shopCartService.exception.OrderNotFoundExcpetion;
import com.saggezza.shopCartService.exception.ValueNotFoundException;
import com.saggezza.shopCartService.pojos.Order;
import com.saggezza.shopCartService.pojos.Orders;
import com.saggezza.shopCartService.pojos.Users;
import com.saggezza.shopCartService.service.ShoppingCartService;

import io.swagger.annotations.Api;


@RestController
@RequestMapping("/shoppingCart")
@Api(description = "provide userId,productId and catalogId in json to add/remove an item to cart => {\r\n" + 
		" \"catalogId\":2,\r\n" + 
		"\"productId\":4,\r\n" + 
		"\"userId\":1\r\n" + 
		"}")
public class ShoppingCartController {
	
	@Autowired
	ShoppingCartService shoppingCartService;
	
	@Autowired
	Orders orders;
	@Autowired
    Users users;
	
	
	//It must be post method for but for the ease
	@PostMapping(path="/add")
	public Order addToCart(@RequestBody Map<String, Object> userMap){
		int userId=(int)fetchValue(userMap, "userId");
		int productId=(int)fetchValue(userMap, "productId");
		int catalogId=(int)fetchValue(userMap, "catalogId");
		Order order=shoppingCartService.addtocart(userId, productId, catalogId);
		return order;
	}
	
	@DeleteMapping("/remove")
	public Order removeFromCart(@RequestBody Map<String, Object> userMap){
		int userId=(int)fetchValue(userMap, "userId");
		int productId=(int)fetchValue(userMap, "productId");
		Order order=shoppingCartService.removeFromCart(userId, productId);
		return order;
	}
	
	@GetMapping("findOrderByUserId/{userId}")
	public Order getOrders(@PathVariable int userId) {
		Order order=shoppingCartService.findOrder(userId);
		if(order==null) {
			throw new OrderNotFoundExcpetion("Order not found for userId "+userId, "please try with different user id");
		}
		return order;
	}

	public Object fetchValue(Map<String, Object> userMap ,String key){
		if(!userMap.containsKey(key) || userMap.get(key)==null ) {
			throw new ValueNotFoundException("Either "+key +" not found or it is damaged ","please provide it");
		}
		return userMap.get(key);
	}
	@GetMapping("/getAllUsers")
	public Users getAllUsers() {
		
		return users;
	}
}
