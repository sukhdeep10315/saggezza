package com.saggezza.shopCartService.pojos;

import java.util.List;

public class Order {
	int orderId;
	int userId;
	List<OrderItem> orderitems;
	
	double totolPrice;
	
	public double getTotolPrice() {
		return totolPrice;
	}
	public void setTotolPrice(double totolPrice) {
		this.totolPrice = totolPrice;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public List<OrderItem> getOrderitems() {
		return orderitems;
	}
	public void setOrderitems(List<OrderItem> orderitems) {
		this.orderitems = orderitems;
	}
	
}
