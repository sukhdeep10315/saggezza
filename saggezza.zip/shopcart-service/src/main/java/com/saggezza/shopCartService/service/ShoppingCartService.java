package com.saggezza.shopCartService.service;

import java.util.ArrayList;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.saggezza.shopCartService.exception.OrderNotFoundExcpetion;
import com.saggezza.shopCartService.exception.ProductNotFoundExcpetion;
import com.saggezza.shopCartService.exception.UserNotFoundException;
import com.saggezza.shopCartService.pojos.Order;
import com.saggezza.shopCartService.pojos.OrderItem;
import com.saggezza.shopCartService.pojos.Orders;
import com.saggezza.shopCartService.pojos.Product;
import com.saggezza.shopCartService.pojos.User;
import com.saggezza.shopCartService.pojos.Users;
import com.saggezza.shopCartService.proxy.FetchProductProxy;


@Service
public class ShoppingCartService {
	
    @Autowired
	Orders orders;
    
    @Autowired
    Users users;
    
    @Autowired
    FetchProductProxy fetchProductPrxy;
    
    public Order addtocart(int userId,int productId,int catalogId){
    	Order order1=null;
    	checkUserExists(userId);
    	Product product=checkIfProductExists(productId,catalogId);
    	if(!product.isAvailable()) {
    		throw new ProductNotFoundExcpetion("this product currenty unavailable", "try after sometime");
    	}
    	boolean userHasOrderAlready=false;
    	if(orders.getOrders()==null) {
    		orders.setOrders(new ArrayList<Order>());
    	}
    	for(Order order:orders.getOrders()) {
    		if(order.getUserId()==userId) {
    			order1=order;
    			userHasOrderAlready=true;
    			OrderItem orderItem=new OrderItem();
    			orderItem.setOrderId(order.getOrderId());
    			orderItem.setOrderItemId(new Random().nextInt(100));
    			orderItem.setProductId(productId);
    			orderItem.setProductPrice(product.getProductPrice());
    			order.getOrderitems().add(orderItem);
    			double price=0.0;
    			for(OrderItem orderItem2:order.getOrderitems()) {
    				price=price +orderItem2.getProductPrice();
    			}
    			order.setTotolPrice(price);
    		}
    	}
    	
    	if(!userHasOrderAlready) {
    		Order order=new Order();
    		order.setOrderId(new Random().nextInt(100));
    		order.setUserId(userId);
    		OrderItem orderItem=new OrderItem();
			orderItem.setOrderId(order.getOrderId());
			orderItem.setOrderItemId(new Random().nextInt(100));
			orderItem.setProductId(productId);
			orderItem.setProductPrice(product.getProductPrice());
			if(order.getOrderitems()==null) {
				order.setOrderitems(new ArrayList<>());
	    	}
			order.getOrderitems().add(orderItem);
			double price=0.0;
			for(OrderItem orderItem2:order.getOrderitems()) {
				price=+orderItem2.getProductPrice();
			}
			order.setTotolPrice(price);
			order1=order;
			orders.getOrders().add(order1);
    	}
    	
    	return order1;
    }
    
    private Product checkIfProductExists(int productId,int catalogId) {
    	Product prod=fetchProductPrxy.getSingleProduct(productId, catalogId);
    	if(prod==null) {
    		throw new ProductNotFoundExcpetion("Product id"+productId+ "not found from catalog"+catalogId, "hit product service");
    	}
		return prod;
	}

	private User checkUserExists(int userId) {
    	User user=null;
    	for(User tmpUser:users.getUsers()) {
    		if(tmpUser.getId()==userId) {
    			user=tmpUser;
    		}
    	}
    	if(user==null) {
    		throw new UserNotFoundException("User doesnot exist", "try with differnt id from 1 to 5");
    	}
    	return user;
	}

	public Order removeFromCart(int userId,int productId){
		Order order1=null;
		boolean orderFound=false;
		boolean productFound=false;
		if(orders.getOrders()==null) {
    		orders.setOrders(new ArrayList<Order>());
    	}
		OrderItem ordNeedTobedeleted=null;
		for(Order order:orders.getOrders()) {
			if(order.getUserId()==userId) {
				order1=order;
				orderFound=true;
				for(OrderItem orderItem:order.getOrderitems()) {
					if(orderItem.getProductId()==productId) {
						productFound=true;
						ordNeedTobedeleted=orderItem;
					}
				}
				order.getOrderitems().remove(ordNeedTobedeleted);
			}
		}
		if(!orderFound) {
			throw new OrderNotFoundExcpetion("no order found for user "+userId, "Thanks for using service");
		}
		if(!productFound) {
			throw new ProductNotFoundExcpetion("no product "+productId+" found for order "+order1.getOrderId(), "Thanks for using service");
		}
		order1.getOrderitems().remove(null);
		double price=0.0;
		for(OrderItem orderItem2:order1.getOrderitems()) {
			price=price +orderItem2.getProductPrice();
		}
		order1.setTotolPrice(price);
		return order1;
    }
	

	public Order findOrder(int userId) {
		if(orders.getOrders()==null) {
    		orders.setOrders(new ArrayList<Order>());
    	}
		for(Order order:orders.getOrders()) {
			if(order.getUserId()==userId) {
				return order;
			}
		}
		return null;
	}
}
