package com.saggezza.shopCartService.exception;

public class OrderNotFoundExcpetion extends RuntimeException {
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorDetails() {
		return errorDetails;
	}

	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String errorMessage;
	public String errorDetails;
	
	public OrderNotFoundExcpetion(String errorMessage,String errorDetails) {
		this.errorDetails=errorDetails;
		this.errorMessage=errorMessage;
	}
}
