package com.saggezza.shopCartService.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.saggezza.shopCartService.pojos.Product;



@FeignClient(name="ss",url="http://localhost:8080/cat-prod-service")
public interface FetchProductProxy {
	
	@GetMapping("/catalogProducts/{catalogId}/productId/{id}")
	public Product getSingleProduct(@PathVariable int id,@PathVariable int catalogId);

}
