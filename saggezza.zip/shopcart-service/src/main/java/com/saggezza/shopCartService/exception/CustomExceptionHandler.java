package com.saggezza.shopCartService.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;

@RestControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {
	@Autowired
	CustomErrorResponse customErrorResponse;
	
	@ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
        List<String> details = new ArrayList<>();
        details.add(ex.getLocalizedMessage());
        details.add("Unhandled Instance class exception  -->  "+ex.getClass().getCanonicalName());
        customErrorResponse.setErroMessage("Server Unwanted Error");
        customErrorResponse.setErrorDetails(details);
        return new ResponseEntity<Object>(customErrorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
	@ExceptionHandler(OrderNotFoundExcpetion.class)
    public final ResponseEntity<Object> handleAllExceptions(OrderNotFoundExcpetion ex, WebRequest request) {
        List<String> details = new ArrayList<>(); 
        details.add(ex.getErrorDetails());
        customErrorResponse.setErroMessage(ex.getErrorMessage());
        customErrorResponse.setErrorDetails(details);
        return new ResponseEntity<Object>(customErrorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
	@ExceptionHandler(ProductNotFoundExcpetion.class)
    public final ResponseEntity<Object> handleAllExceptions(ProductNotFoundExcpetion ex, WebRequest request) {
        List<String> details = new ArrayList<>(); 
        details.add(ex.getErrorDetails());
        customErrorResponse.setErroMessage(ex.getErrorMessage());
        customErrorResponse.setErrorDetails(details);
        return new ResponseEntity<Object>(customErrorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
	@ExceptionHandler(UserNotFoundException.class)
    public final ResponseEntity<Object> handleAllExceptions(UserNotFoundException ex, WebRequest request) {
        List<String> details = new ArrayList<>(); 
        details.add(ex.getErrorDetails());
        customErrorResponse.setErroMessage(ex.getErrorMessage());
        customErrorResponse.setErrorDetails(details);
        return new ResponseEntity<Object>(customErrorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
	@ExceptionHandler(ValueNotFoundException.class)
    public final ResponseEntity<Object> handleAllExceptions(ValueNotFoundException ex, WebRequest request) {
        List<String> details = new ArrayList<>(); 
        details.add(ex.getErrorDetails());
        customErrorResponse.setErroMessage(ex.getErrorMessage());
        customErrorResponse.setErrorDetails(details);
        return new ResponseEntity<Object>(customErrorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
	

}
