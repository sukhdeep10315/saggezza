package com.saggezza.shopCartService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;

import com.saggezza.shopCartService.pojos.User;
import com.saggezza.shopCartService.pojos.Users;



@SpringBootApplication
@EnableFeignClients
@EnableDiscoveryClient
public class ShoppingCartServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingCartServiceApplication.class, args);
	}

	@Bean
	public Users getUserList() {
		//Wanted to use from reqres.in but was getting forbidden 
	   User u1=new User(1,"george.bluth@reqres.in","George","Bluth");
	   User u2=new User(2,"janet.weaver@reqres.in","janet","weaver");
	   User u3=new User(3,"emma.wong@reqres.in","emma","wong");
	   User u4=new User(4,"eve.holt@reqres.in","eve","holt");
	   User u5=new User(5,"charles.morris@reqres.in","Charles","morris");
	   List<User> users=new ArrayList<>();
	   users.add(u1);
	   users.add(u2);
	   users.add(u3);
	   users.add(u4);
	   users.add(u5);
	   Users users1=new Users();
	   users1.setUsers(users);
	   return users1;
	}
	
}
