package com.saggezza.shopCartService.pojos;

import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class Orders {

	List<Order> orders;

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	
}
