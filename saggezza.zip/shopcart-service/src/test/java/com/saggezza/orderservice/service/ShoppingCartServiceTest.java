package com.saggezza.orderservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.saggezza.shopCartService.pojos.Order;
import com.saggezza.shopCartService.pojos.Orders;
import com.saggezza.shopCartService.pojos.Product;
import com.saggezza.shopCartService.pojos.User;
import com.saggezza.shopCartService.pojos.Users;
import com.saggezza.shopCartService.proxy.FetchProductProxy;
import com.saggezza.shopCartService.service.ShoppingCartService;



@ExtendWith(MockitoExtension.class)
@TestMethodOrder(OrderAnnotation.class)
@TestInstance(Lifecycle.PER_CLASS)
public class ShoppingCartServiceTest {

	@Mock
	Orders ordersMock;

	@Mock
	Users usersMock;

	@Mock
	FetchProductProxy fetchProductPrxyMock;

	@InjectMocks
	ShoppingCartService shoppingCartServiceMock;
	
	public Order order;

	public Product getProduct() {
		Product p1 = new Product(1, "shirt", "bodywear", 45.0, true);
		return p1;
	}

	public List<User> getUsers() {
		User u1 = new User(1, "george.bluth@reqres.in", "George", "Bluth");
		List<User> users1 = new ArrayList<>();
		users1.add(u1);
		return users1;
	}

	@Test
    @org.junit.jupiter.api.Order(1)
	public void addToCartTest() {
		Mockito.when(fetchProductPrxyMock.getSingleProduct(1, 1)).thenReturn(getProduct());
		Mockito.when(usersMock.getUsers()).thenReturn(getUsers());
		Mockito.when(ordersMock.getOrders()).thenReturn(new ArrayList<>());
	    order=shoppingCartServiceMock.addtocart(1, 1, 1);
		assertNotNull(order);
		assertEquals(order.getUserId(),1);
	}

	@Test
	@org.junit.jupiter.api.Order(3) 
	public void removeFromCart() {
		List<Order> orders=new ArrayList<>();
		orders.add(order);
		Mockito.when(ordersMock.getOrders()).thenReturn(orders);
		order=shoppingCartServiceMock.removeFromCart(1, 1);
		assertEquals(order.getTotolPrice(),0.0);
	}

	

	@Test
	@org.junit.jupiter.api.Order(2) 
	public void findOrder() {
		List<Order> orders=new ArrayList<>();
		orders.add(order);
		Mockito.when(ordersMock.getOrders()).thenReturn(orders);
		order=shoppingCartServiceMock.findOrder(1);
		assertNotNull(order);
		assertEquals(order.getUserId(),1);
	}
}
